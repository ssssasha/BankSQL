package com.oop;

public class ChildbirthDepartment extends Department{

    private int numberOfBeds;

    public ChildbirthDepartment() {
    }

    public ChildbirthDepartment(int numberOfStaff, int numberOfPatients, int numberOfBeds) {
        super(numberOfStaff, numberOfPatients);
        this.numberOfBeds = numberOfBeds;
    }

    public int getNumberOfBeds() {
        return this.numberOfBeds;
    }

    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;

    }

}

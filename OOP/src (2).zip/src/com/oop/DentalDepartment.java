package com.oop;

public class DentalDepartment extends Department {

    public DentalDepartment() {
    }

    public DentalDepartment(int numberOfStaff, int numberOfPatients) {
        super(numberOfStaff, numberOfPatients);
    }

}

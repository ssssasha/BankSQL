package com.oop;

public class Hospital {

    public static void main(String[] args) {
        Patient patient1 = new Patient("Іван", "Коваленко", 22, "вул.Зелена 3", "+0983425467");
        Patient patient2 = new Patient("Іван", "Cидорчук", 18, "вул.Зелена 5", "+0983428888");
        //System.out.println(patient1.toString());
        //System.out.println(patient1.equals(patient2));
        //System.out.println(patient1.hashCode()==patient2.hashCode());

        Staff staff1 = new Staff("Алла", "Сидорчук", 32, "лікар", 8, "+0972316272");
        Staff staff2 = new Staff("Алла", "Сидорчук", 40, "лікар", 8, "+964834832");
        //System.out.println(staff1.toString());
        //staff1.display();
        System.out.println(staff1.equals(staff2));
        Doctor doctor1 = new Doctor("Алла", "Сидорчук", 32, "лікар", "травматолог",
                8, "+0972316272");
        Doctor doctor2 = new Doctor("Алла", "Сидорчук", 29, "лікар", "травматолог",
                8, "+0972316272");
        System.out.println(doctor1.equals(doctor2));
        Visit visit1 = new Visit(1, "Понеділок", 10.30, "Алла Сидорчук", "Іван Коваленко");
        Visit visit2 = new Visit(1, "Понеділок", 12.30, "Алла Сидорчук", "Іван Коваленко");
        System.out.println(visit1.equals(visit2));
        Speciality speciality = new Speciality("стоматолог");
        System.out.println(speciality.hashCode());

    }
}


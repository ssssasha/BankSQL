package com.oop;

public class Visit {
    private int number;
    private String day;
    private double time;
    private String doctor;
    private String patient;

    public Visit() {
    }

    public Visit(int number, String day, double time, String doctor, String patient) {
        this.number = number;
        this.day = day;
        this.time = time;
        this.doctor = doctor;
        this.patient = patient;
    }

    public int getNumber() {
        return this.number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getDay() {
        return this.day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public double getTime() {
        return this.time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public String getDoctor() {
        return this.doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    public String getPatient() {
        return this.patient;
    }

    public void setPatient(String patient) {
        this.patient = patient;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Visit visit = (Visit) obj;
        return number == visit.number && (day == visit.day
                || (day != null && day.equals(visit.day)))
                && (doctor == visit.doctor
                || (doctor != null && doctor.equals(visit.doctor)));
        //return Objects.equals(super.getName(), patient.getName());
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((day == null) ? 0 : day.hashCode());
        result = prime * result + number;
        result = prime * result + ((doctor == null) ? 0 : doctor.hashCode());
        return result;
    }
}

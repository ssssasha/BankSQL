package com.oop;

public class CardiologyDepartment {
    private int numberOfStaff;
    private int numberOfPatients;
    private int numberOfBeds;

    public CardiologyDepartment() {
    }

    public CardiologyDepartment(int numberOfStaff, int numberOfPatients, int numberOfBeds) {
        this.numberOfStaff = numberOfStaff;
        this.numberOfPatients = numberOfPatients;
        this.numberOfBeds = numberOfBeds;
    }

    public int getNumberOfStaff() {
        return this.numberOfStaff;
    }

    public void setNumberOfStaff(int numberOfStaff) {
        this.numberOfStaff = numberOfStaff;
    }

    public int getNumberOfPatients() {
        return this.numberOfPatients;
    }

    public void setNumberOfPatients(int numberOfPatients) {
        this.numberOfPatients = numberOfPatients;
    }

    public int getNumberOfBeds() {
        return this.numberOfBeds;
    }

    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;
    }
}

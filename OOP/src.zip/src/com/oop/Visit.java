package com.oop;

public class Visit {
    private int number;
    private String day;
    private int time;
    private String doctor;
    private String patient;

    public Visit() {
    }

    public Visit(int number, String day, int time, String doctor, String patient) {
        this.number = number;
        this.day = day;
        this.time = time;
        this.doctor = doctor;
        this.patient = patient;
    }

    public int getNumber() {
        return this.number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getDay() {
        return this.day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public int getTime() {
        return this.time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public String getDoctor() {
        return this.doctor;
    }

    public void setDoctor(String doctor) {
        this.doctor = doctor;
    }

    public String getPatient() {
        return this.patient;
    }

    public void setPatient(String patient) {
        this.patient = patient;
    }
}

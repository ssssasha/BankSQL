package com.oop;

public class DentalDepartment {
    private int numberOfStaff;
    private int numberOfPatients;

    public DentalDepartment() {
    }

    public DentalDepartment(int numberOfStaff, int numberOfPatients) {
        this.numberOfStaff = numberOfStaff;
        this.numberOfPatients = numberOfPatients;
    }

    public int getNumberOfStaff() {
        return this.numberOfStaff;
    }

    public void setNumberOfStaff(int numberOfStaff) {
        this.numberOfStaff = numberOfStaff;
    }

    public int getNumberOfPatients() {
        return this.numberOfPatients;
    }

    public void setNumberOfPatients(int numberOfPatients) {
        this.numberOfPatients = numberOfPatients;
    }
}

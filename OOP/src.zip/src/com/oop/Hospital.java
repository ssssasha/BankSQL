package com.oop;

public class Hospital {

    public static void main(String[] args) {
	    Patient patient1 = new Patient("Іван", "Коваленко", 22, "вул.Зелена 3", "+0983425467" );
        System.out.println(patient1.getName());
        System.out.println(patient1.getAge());
        System.out.println(patient1.getAddress());
        patient1.setAge(17);
        System.out.println(patient1.getAge());
        Patient patient2 = new Patient("Олена");
        System.out.println(patient2.getName());
        System.out.println(patient2.getSurname());
        patient2.setName("Марія");
        System.out.println(patient2.getName());
        System.out.println(patient2.getAge());
    }
}


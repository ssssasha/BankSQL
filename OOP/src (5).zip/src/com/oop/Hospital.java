package com.oop;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Hospital {

    public static ArrayList<Patient> generatePatients(){
        ArrayList<Patient> patients = new ArrayList<Patient>();
        patients.add(new Patient("James", "Smith", 22, "Park street", "+0983425467"));
        patients.add(new Patient("James", "Brown", 18, "Park street", "+0983428888"));
        patients.add(new Patient());
        return patients;
    }

    public static ArrayList<Doctor> generateDoctors(){
        ArrayList<Doctor> doctors = new ArrayList<Doctor>();
        doctors.add(new Doctor("Emma", "Miller", 32, "doctor", "traumatologist",
                8, "+0972316272"));
        doctors.add(new Doctor("Olivia", "Miller", 29, "doctor", "traumatologist",
                8, "+0972316272"));
        doctors.add(new Doctor("Margaret", "Miller", 29, "doctor", "dentist",
                5, "+0972316271"));
        return doctors;
    }

    public static ArrayList<Visit> generateVisits(){
        ArrayList<Visit> visits = new ArrayList<Visit>();
        visits.add(new Visit(1, "Monday", 10.30, generateDoctors().get(0), generatePatients().get(0)));
        visits.add(new Visit(1, "Tuesday", 12.30, generateDoctors().get(1), generatePatients().get(1)));
        visits.add(new Visit(2, "Wednesday", 12.30, generateDoctors().get(2), generatePatients().get(0)));
        visits.add(new Visit(2, "Thursday", 12.30, generateDoctors().get(2), generatePatients().get(1)));
        return visits;
    }

    public static Map<String, Visit> reception(){
        Map<String, Visit> reсeptions =  new HashMap<String, Visit>();
        reсeptions.put("Monday", generateVisits().get(0));
        reсeptions.put("Tuesday", generateVisits().get(1));
        reсeptions.put("Wednesday", generateVisits().get(2));
        return reсeptions;
    }

}


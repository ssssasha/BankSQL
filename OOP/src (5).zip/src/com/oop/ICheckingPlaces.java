package com.oop;

public interface ICheckingPlaces {
     void check();
}

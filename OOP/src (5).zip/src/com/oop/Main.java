package com.oop;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {
    private final static Logger LOGGER = LogManager.getLogger(Main.class);

    public static void main(String[] args) {

       List<Patient> patientList = Hospital.generatePatients();
        //patientList.get(2).displayInfo();
        patientList.get(0).displayInfo();
        patientList.get(1).displayInfo();
        LOGGER.info(patientList.get(1).toString());
        //System.out.println(patient1.equals(patient2));
        //System.out.println(patient1.hashCode()==patient2.hashCode());
        List<Doctor> doctorList = Hospital.generateDoctors();
        doctorList.get(0).displayInfo();
        List<Visit> visitList = Hospital.generateVisits();
//        System.out.println(doctor1.equals(doctor2));
//        System.out.println(visit1.equals(visit2));
//        Speciality speciality = new Speciality("стоматолог");
//        System.out.println(speciality.hashCode());
          LOGGER.info(visitList.get(1));

        CardiologyDepartment cardiologyDepartment = new CardiologyDepartment();
        cardiologyDepartment.setInfo();
        cardiologyDepartment.check();
        ChildbirthDepartment childbirthDepartment = new ChildbirthDepartment();
        childbirthDepartment.setInfo();
        childbirthDepartment.check();
        DentalDepartment.CheckQueue();

        Map<String, Visit> reseptionList = Hospital.reception();
        LOGGER.info(reseptionList.get("Monday"));

    }
}

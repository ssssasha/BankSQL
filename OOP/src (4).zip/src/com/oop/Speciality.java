package com.oop;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Speciality implements ISetInfo, IDisplayInfo {

    private final static Logger LOGGER = LogManager.getLogger(Speciality.class);
    private String name;

    public Speciality() {
    }

    public Speciality(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void setInfo() {
        setName("стоматолог");
    }

    @Override
    public void displayInfo() {
        LOGGER.info(name);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    @Override
    public String toString() {
        return "Speciality: " + " " + name;
    }
}

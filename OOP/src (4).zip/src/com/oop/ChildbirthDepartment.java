package com.oop;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ChildbirthDepartment extends Department implements ICheckingPlaces {

    private final static Logger LOGGER = LogManager.getLogger(ChildbirthDepartment.class);
    private int numberOfBeds;

    public ChildbirthDepartment() {
    }

    public ChildbirthDepartment(int numberOfStaff, int numberOfPatients, int numberOfBeds) {
        super(numberOfStaff, numberOfPatients);
        this.numberOfBeds = numberOfBeds;
    }

    public int getNumberOfBeds() {
        return this.numberOfBeds;
    }

    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;

    }

    public void setInfo() {
        setNumberOfBeds(40);
        setNumberOfPatients(42);
        setNumberOfStaff(20);
    }

    public void check() {
        try{
            if(getNumberOfBeds() < getNumberOfPatients()){
                throw new Exception("Not enough beds");
            }
        }
        catch(Exception ex){
            //ex.printStackTrace();
            LOGGER.error(ex.getMessage());
        }
    }

    @Override
    public String toString() {
        return "ChildbirthDepartment: " + " " + super.getNumberOfStaff() + " " + super.getNumberOfPatients() + " " + numberOfBeds;
    }

}

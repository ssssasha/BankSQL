package com.oop;

public interface IDisplayInfo {

     void displayInfo();
}

package com.oop;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PediatricsDepartment extends Department implements ICheckingPlaces {

    private final static Logger LOGGER = LogManager.getLogger(PediatricsDepartment.class);
    private int numberOfBeds;

    public PediatricsDepartment() {
    }

    public PediatricsDepartment(int numberOfStaff, int numberOfPatients, int numberOfBeds) {
        super(numberOfStaff, numberOfBeds);
        this.numberOfBeds = numberOfBeds;
    }

    public int getNumberOfBeds() {
        return this.numberOfBeds;
    }

    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;
    }

    public void setInfo() {
        setNumberOfBeds(42);
        setNumberOfPatients(20);
        setNumberOfStaff(22);
    }

    public void check() {
        try{
            if(getNumberOfBeds() < getNumberOfPatients()){
                throw new Exception("Not enough beds");
            }
        }
        catch(Exception ex){
            //ex.printStackTrace();
            LOGGER.error(ex.getMessage());
        }
    }

    @Override
    public String toString() {
        return "PediatricsDepartment: " + " " + super.getNumberOfStaff() + " " + super.getNumberOfPatients() + " " + numberOfBeds;
    }
}

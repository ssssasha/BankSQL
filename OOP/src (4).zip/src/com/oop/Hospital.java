package com.oop;

import java.util.Scanner;

public class Hospital {

    public static void main(String[] args) {
        Patient patient1 = new Patient("James", "Smith", 22, "Park street", "+0983425467");
        Patient patient2 = new Patient("James", "Brown", 18, "Park street", "+0983428888");
        Patient patient3 = new Patient();
        patient3.displayInfo();
        patient1.displayInfo();
        patient2.displayInfo();
        //System.out.println(patient1.toString());
        //System.out.println(patient1.equals(patient2));
        //System.out.println(patient1.hashCode()==patient2.hashCode());
        Doctor doctor1 = new Doctor("Emma", "Miller", 32, "doctor", "traumatologist",
                8, "+0972316272");
        Doctor doctor2 = new Doctor("Olivia", "Miller", 29, "doctor", "traumatologist",
                8, "+0972316272");
        doctor1.displayInfo();
//        System.out.println(doctor1.equals(doctor2));
        Visit visit1 = new Visit(1, "Понеділок", 10.30, doctor1, patient1);
        Visit visit2 = new Visit(1, "Понеділок", 12.30, doctor2, patient2);
//        System.out.println(visit1.equals(visit2));
//        Speciality speciality = new Speciality("стоматолог");
//        System.out.println(speciality.hashCode());
//        System.out.println(visit1);
        TraumaDepartment traumaDepartment = new TraumaDepartment();
        traumaDepartment.setInfo();
        traumaDepartment.check();

        Speciality speciality = new Speciality();
        speciality.setInfo();
        speciality.displayInfo();

        CardiologyDepartment cardiologyDepartment = new CardiologyDepartment();
        cardiologyDepartment.setInfo();
        cardiologyDepartment.check();
        ChildbirthDepartment childbirthDepartment = new ChildbirthDepartment();
        childbirthDepartment.setInfo();
        childbirthDepartment.check();

        DentalDepartment.CheckQueue();

        try{
            Scanner in = new Scanner(System.in);
            int x = in.nextInt();
            if(x>31){
                throw new Exception("The number can't be greater than 31");
            }
        }
        catch(Exception ex){
            //ex.printStackTrace();
            System.out.println(ex.getMessage());
        }
    }
}


package com.oop;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

public class CardiologyDepartment extends Department implements ICheckingPlaces {

    private final static Logger LOGGER = LogManager.getLogger(CardiologyDepartment.class);
    private int numberOfBeds;

    public CardiologyDepartment() {
    }

    public CardiologyDepartment(int numberOfStaff, int numberOfPatients, int numberOfBeds) {
        super(numberOfStaff, numberOfPatients);
        this.numberOfBeds = numberOfBeds;
    }

    public int getNumberOfBeds() {
        return this.numberOfBeds;
    }

    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;
    }

    public void setInfo() {
        setNumberOfBeds(32);
        setNumberOfPatients(33);
        setNumberOfStaff(15);
    }

    public void check() {
        try{
            if(getNumberOfBeds() < getNumberOfPatients()){
                throw new Exception("Not enough beds");
            }
        }
        catch(Exception ex){
            //ex.printStackTrace();
            //System.out.println(ex.getMessage());
            LOGGER.error(ex.getMessage());
        }
    }

    @Override
    public String toString() {
        return  "CardiologyDepartment: " + " " + super.getNumberOfStaff() + " " + super.getNumberOfPatients()
                + " " + numberOfBeds;
    }
}

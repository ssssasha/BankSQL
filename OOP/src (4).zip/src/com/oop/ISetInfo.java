package com.oop;

public interface ISetInfo {

     void setInfo();
}

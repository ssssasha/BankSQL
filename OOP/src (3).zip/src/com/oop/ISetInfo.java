package com.oop;

public interface ISetInfo {

    public void setInfo();
}

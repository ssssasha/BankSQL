package com.oop;

public interface IDisplayInfo {

    public void displayInfo();
}

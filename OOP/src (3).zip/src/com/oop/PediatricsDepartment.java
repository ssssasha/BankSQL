package com.oop;

public class PediatricsDepartment extends Department implements ICheckingPlaces {

    private int numberOfBeds;

    public PediatricsDepartment() {
    }

    public PediatricsDepartment(int numberOfStaff, int numberOfPatients, int numberOfBeds) {
        super(numberOfStaff, numberOfBeds);
        this.numberOfBeds = numberOfBeds;
    }

    public int getNumberOfBeds() {
        return this.numberOfBeds;
    }

    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;
    }

    public void setInfo() {
        setNumberOfBeds(42);
        setNumberOfPatients(20);
        setNumberOfStaff(22);
    }

    public void check() {
        if (getNumberOfBeds() < getNumberOfPatients()) {
            System.out.println("Потрібні додаткові місця");
        } else
            System.out.println("Місць достатньо");
    }

    @Override
    public String toString() {
        return super.getNumberOfStaff() + " " + super.getNumberOfPatients() + " " + numberOfBeds;
    }
}

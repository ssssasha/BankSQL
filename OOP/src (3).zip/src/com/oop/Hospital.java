package com.oop;

public class Hospital {

    public static void main(String[] args) {
        Patient patient1 = new Patient("Іван", "Коваленко", 22, "вул.Зелена 3", "+0983425467");
        Patient patient2 = new Patient("Іван", "Cидорчук", 18, "вул.Зелена 5", "+0983428888");
        patient1.displayInfo();
        patient2.displayInfo();
        patient1.display();
        //System.out.println(patient1.toString());
        //System.out.println(patient1.equals(patient2));
        //System.out.println(patient1.hashCode()==patient2.hashCode());
        Doctor doctor1 = new Doctor("Алла", "Сидорчук", 32, "лікар", "травматолог",
                8, "+0972316272");
        Doctor doctor2 = new Doctor("Олена", "Сидорчук", 29, "лікар", "травматолог",
                8, "+0972316272");
        doctor1.displayInfo();
        doctor2.display();
//        System.out.println(doctor1.equals(doctor2));
        Visit visit1 = new Visit(1, "Понеділок", 10.30, doctor1, patient1);
        Visit visit2 = new Visit(1, "Понеділок", 12.30, doctor2, patient2);
//        System.out.println(visit1.equals(visit2));
//        Speciality speciality = new Speciality("стоматолог");
//        System.out.println(speciality.hashCode());
//        System.out.println(visit1);
        TraumaDepartment traumaDepartment = new TraumaDepartment();
        traumaDepartment.setInfo();
        System.out.println(traumaDepartment.getNumberOfBeds());
        System.out.println(traumaDepartment.getNumberOfPatients());
        System.out.println(traumaDepartment.getNumberOfStaff());
        TraumaDepartment.checking();

        Speciality speciality = new Speciality();
        speciality.setInfo();
        speciality.displayInfo();

        CardiologyDepartment cardiologyDepartment = new CardiologyDepartment();
        cardiologyDepartment.setInfo();
        cardiologyDepartment.check();
        ChildbirthDepartment childbirthDepartment = new ChildbirthDepartment();
        childbirthDepartment.setInfo();
        childbirthDepartment.check();

        DentalDepartment.CheckQueue();
    }
}


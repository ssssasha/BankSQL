package com.oop;

import java.util.Objects;

public class Patient extends Person {

    private String address;

    public Patient() {
    }

    public Patient(String name, String surname, int age, String address, String phone) {
        super(name, surname, age, phone);
        this.address = address;
    }

    public String getAddress() {
        return this.address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public void display() {
        System.out.println("Name:" + " " + super.getName() + "  " + "Surname:" + " " + super.getSurname() + "  " + "Age:"
                + " " + super.getAge() + "  " + "address:" + " " + address);
    }

    public void displayInfo() {
        System.out.println(super.getName() + " " + super.getSurname() + " " + super.getAge() + " " + address);
    }

    @Override
    public String toString() {
        return super.getName() + " " + super.getSurname() + " " + address;
    }

    @Override
    public int hashCode() {
        //System.out.println((10 * super.getName().hashCode() + 20456));
        //return 10 * super.getName().hashCode() + 20456;
        final int prime = 31;
        int result = 1;
        result = prime * result + ((super.getName() == null) ? 0 : super.getName().hashCode());
        System.out.println(result);
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Patient patient = (Patient) obj;
        return Objects.equals(super.getName(), patient.getName());
    }
}

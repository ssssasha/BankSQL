package com.oop;

public class Schedule {
    private String day;
    private double startOfReception;
    private double endOfReception;
    private int office;

    public Schedule() {
    }

    public Schedule(String day, double startOfReception, double endOfReception, int office) {
        this.day = day;
        this.startOfReception = startOfReception;
        this.endOfReception = endOfReception;
        this.office = office;
    }

    public String getDay() {
        return this.day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public double getStartOfReception() {
        return this.startOfReception;
    }

    public void setStartOfReception(double startOfReception) {
        this.startOfReception = startOfReception;
    }

    public double getEndOfReception() {
        return this.endOfReception;
    }

    public void setEndOfReception(double endOfReception) {
        this.endOfReception = endOfReception;
    }

    public int getOffice() {
        return this.office;
    }

    public void setOffice(int office) {
        this.office = office;
    }

    @Override
    public String toString() {
        return day + " " + startOfReception + " " + endOfReception;
    }
}

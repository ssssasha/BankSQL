package com.oop;

public class TraumaDepartment extends Department {

    private int numberOfBeds;
    static int numOfBeds = 10;
    static int numOfPatients = 14;

    public TraumaDepartment() {
    }

    public TraumaDepartment(int numberOfStaff, int numberOfPatients, int numberOfBeds) {
        super(numberOfStaff, numberOfBeds);
        this.numberOfBeds = numberOfBeds;
    }

    public int getNumberOfBeds() {
        return this.numberOfBeds;
    }

    public void setNumberOfBeds(int numberOfBeds) {
        this.numberOfBeds = numberOfBeds;
    }

    @Override
    public String toString() {
        return super.getNumberOfStaff() + " " + super.getNumberOfPatients() + " " + numberOfBeds;
    }

    public void setInfo() {
        setNumberOfBeds(28);
        setNumberOfPatients(7);
        setNumberOfStaff(14);
    }

    public static void checking(){
        if (numOfBeds < numOfPatients) {
            System.out.println("Потрібні додаткові місця");
        }
        else
            System.out.println("Місць достатньо");
    }
}

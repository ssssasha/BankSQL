package com.oop;

public class DentalDepartment extends Department {
    static int dentalChairs = 4;
    static int numOfClients = 5;

    public DentalDepartment() {
    }

    public DentalDepartment(int numberOfStaff, int numberOfPatients) {
        super(numberOfStaff, numberOfPatients);
    }

    public void setInfo() {
        setNumberOfPatients(3);
        setNumberOfStaff(10);
    }

    @Override
    public String toString() {
        return super.getNumberOfStaff() + " " + super.getNumberOfPatients();
    }

    public static void CheckQueue() {
        if (numOfClients > dentalChairs) {
            System.out.println("Є черга");
        } else
            System.out.println("Черги немає");
    }
}

package com.oop;

public interface ICheckingPlaces {
    public void check();
}

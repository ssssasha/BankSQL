package com.solvd.hospital.fuctionalInterfaces;

@FunctionalInterface
public interface ISearch {
    boolean find(String secondName);
}

package com.solvd.hospital.interfaces;

public interface ISetInfo {

    void setInfo();
}

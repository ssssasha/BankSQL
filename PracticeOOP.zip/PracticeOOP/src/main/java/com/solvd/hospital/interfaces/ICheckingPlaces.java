package com.solvd.hospital.interfaces;

public interface ICheckingPlaces {
    void check();
}

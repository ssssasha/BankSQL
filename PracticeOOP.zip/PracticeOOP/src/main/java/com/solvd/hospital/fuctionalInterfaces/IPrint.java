package com.solvd.hospital.fuctionalInterfaces;

@FunctionalInterface
public interface IPrint<T> {
    void print(T t);
}

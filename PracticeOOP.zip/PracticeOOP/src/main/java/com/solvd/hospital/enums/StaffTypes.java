package com.solvd.hospital.enums;

public enum StaffTypes {
    DOCTOR,
    OBSTETRICIAN,
    NURSE,
    MEDICAL_ASSISTANT
}

package com.solvd.hospital.interfaces;

public interface IDisplayInfo {

    void displayInfo();
}

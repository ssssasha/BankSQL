import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.nio.file.Paths;
import java.nio.file.Files;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static org.testng.Assert.*;
//import org.testng.reporters.Files;
import java.io.IOException;
import java.nio.file.Paths;
import java.io.*;
import java.util.*;
public class AppTest
{
    public static App app;

    @BeforeClass
    public static void setUpClass() throws IOException{
        System.out.println("before all");
        File file1 = new File("text1.txt");
        if (file1.createNewFile())
        {
            System.out.println("File is created!");
        } else {
            System.out.println("File already exists.");
        }
    }
    @AfterClass
    public static void afterClassMethod(){
        System.out.println("after all");
        File file1 = new File("text1.txt");
        file1.delete();
    }
    @BeforeMethod
    public void setUp(){
        System.out.println("before");
        try(FileWriter writer = new FileWriter("text1.txt", false))
        {

            String text = "kndfsfnd fjsdkfsdkfn vvvg smfsdnfsmndfmsjfndf smfsdnfsmndfmsjdddd";
            writer.write(text);
            writer.flush();
        }
        catch(IOException ex){

            System.out.println(ex.getMessage());
        }
    }
    @DataProvider(name="dataProviderMethod")
    public Object[][] data(){
        return new Object[][] {{"cnscnnc vnjdvn dd", new String[] {"cnscnnc", "vnjdvn", "dd"}},
                {"abc jdnvcjdn kkkpppp ckckckmkcs ncsc", new String[] {"abc", "jdnvcjdn", "kkkpppp", "ckckckmkcs", "ncsc"}}};
    }
    @Test(dataProvider = "dataProviderMethod")
    public void Test( String data, String[] allWords) throws IOException {
        try(FileWriter writer = new FileWriter("text1.txt", false))
        {
            writer.write(data);
        }
        catch(IOException ex){

            System.out.println(ex.getMessage());
        }
        String allW = new String(Files.readAllBytes(Paths.get("text1.txt")));
        String[] wwords = allW.split(" ");
        Assert.assertEquals(wwords, allWords);
        System.out.println("Test");
    }
    @Test
    public void Test1()throws Exception
    {
        App app = new App();
        Assert.assertTrue( app.CutWord("bjkbkjbkjbjkbkjbjkbkjbkjbjnnkjbkjkj").length() == 30);
        System.out.println("Test1");
    }
    @Test
    public void Test2()throws Exception
    {
        App app = new App();
        Assert.assertEquals(app.CutWord("qwertyuiopasdfghjkzxcvbnmqwerty"), app.CutWord("qwertyuiopasdfghjkzxcvbnmqwertydax"));
        System.out.println("Test2");
    }
    @Test
    public void Test3()throws Exception
    {
        App app = new App();
        Assert.assertEquals(app.Filter("fl34o8w(e)r#"), app.Filter("f*l0ow@er"));
        System.out.println("Test3");
    }

    @Test
    public void Test4()throws Exception
    {
        App app = new App();
        String[] words = {"DNnknsks", "snfkndsfknsdf", "smfsdnfsmndfmsjfndf","smfsdnfsmndfmsjdddd"};
        ArrayList<String> result = new ArrayList<String>();
        Assert.assertTrue(App.Result(result,words).size() == 2);
        System.out.println("Test4");
    }

}

